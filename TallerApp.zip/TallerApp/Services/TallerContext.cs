﻿using System.Data.Entity;
using TallerApp.Models;

namespace TallerApp.Services
{

    public class TallerContext : DbContext
    {
        public TallerContext() : base("name=TallerContext") // nombre del connectionString
        {
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // Configuración adicional si es necesaria
         }
    }
}
