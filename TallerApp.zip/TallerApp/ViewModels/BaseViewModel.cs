﻿using System.ComponentModel;
using System.Runtime.CompilerServices;



namespace TallerApp.ViewModels
{
    public class BaseViewModel : INotifyPropertyChanged
    {
        private Services.RelayCommand loginCommand;

        public Services.RelayCommand GetLoginCommand()
        {
            return loginCommand;
        }

        public void SetLoginCommand(Services.RelayCommand value)
        {
            loginCommand = value;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        protected virtual bool SetProperty<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
        {
            if (Equals(field, value))
                return false;

            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }
    }
}